This project contains framework and static library wrappers for external dependencies that don't have them.

Dependencies that are already correctly set up will not be included here.
