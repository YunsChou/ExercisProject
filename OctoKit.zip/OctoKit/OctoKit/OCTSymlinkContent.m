//
//  OCTSymlinkContent.m
//  OctoKit
//
//  Created by Aron Cedercrantz on 14-07-2013.
//  Copyright (c) 2013 GitHub. All rights reserved.
//

#import "OCTSymlinkContent.h"

@implementation OCTSymlinkContent

@end
