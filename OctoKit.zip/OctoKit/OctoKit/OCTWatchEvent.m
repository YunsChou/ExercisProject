//
//  OCTWatchEvent.m
//  OctoKit
//
//  Created by Tyler Stromberg on 12/24/14.
//  Copyright (c) 2014 GitHub. All rights reserved.
//

#import "OCTWatchEvent.h"

@implementation OCTWatchEvent

@end
