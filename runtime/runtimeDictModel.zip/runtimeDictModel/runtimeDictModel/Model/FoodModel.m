//
//  FoodModel.m
//  YsLinkTableView
//
//  Created by weiying on 16/2/14.
//  Copyright © 2016年 Yuns. All rights reserved.
//

#import "FoodModel.h"

@implementation FoodModel

+ (NSDictionary *)arrayContainObjects
{
    return @{@"foodSubs" : @"foodSubs"};
}

@end

@implementation FoodItemModel


@end