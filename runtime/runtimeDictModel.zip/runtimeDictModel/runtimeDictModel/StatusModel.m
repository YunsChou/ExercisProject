//
//  StatusModel.m
//  runtimeDictModel
//
//  Created by weiying on 16/3/18.
//  Copyright © 2016年 Yuns. All rights reserved.
//

#import "StatusModel.h"


@implementation StatusModel

+ (NSDictionary *)arrayContainObjects
{
    return @{
             @"statuses" : @"statusesModel"
             ,
             @"ads" : @"adsModel"
             };
}

@end

@implementation statusesModel


@end

@implementation userModel


@end

@implementation adsModel


@end