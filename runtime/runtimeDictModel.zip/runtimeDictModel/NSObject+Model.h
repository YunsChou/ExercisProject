//
//  NSObject+Model.h
//  runtimeDictModel
//
//  Created by weiying on 16/3/14.
//  Copyright © 2016年 Yuns. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol ModelDelegate <NSObject>

@optional
+ (NSDictionary *)replacedKeyFromePropertyName;

+ (NSDictionary *)arrayContainObjects;

@end

@interface NSObject (Model)

+ (instancetype)modelWithDict:(NSDictionary *)dict;

@end
