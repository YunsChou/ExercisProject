//
//  NSObject+Model.m
//  runtimeDictModel
//
//  Created by weiying on 16/3/14.
//  Copyright © 2016年 Yuns. All rights reserved.
//

#import "NSObject+Model.h"
#import <objc/runtime.h>

@implementation NSObject (Model)

+ (instancetype)modelWithDict:(NSDictionary *)dict
{
    id objc = [[self alloc] init];
    unsigned int count;
    //1、获取类中所有的成员变量列表
    Ivar *ivarList = class_copyIvarList([self class], &count);
    for (int i = 0; i < count; i ++) {
        //↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↑⬇︎⬇︎⬇︎
        //2、根据下标，从成员列表中取出对应的成员变量
        //疑问：Ivar代表变量，为何指向数组带指针，指向普通变量不带指针？
        Ivar ivar = ivarList[i];
        //3、获取成员变量的名称
        const char *ivarName = ivar_getName(ivar);
        //转为将C字符串转为OC字符串
        NSString *name = [NSString stringWithUTF8String:ivarName];
        NSLog(@"name -- %@",name);
        //4、处理成员变量名称 -- 作为字典中的key
        //为什么要将成员变量从第一个位置做截取处理？因为成员变量会在前面生成一个下划线，如@“_age”
        NSString *key = [name substringFromIndex:1];
        NSLog(@"key -- %@",key);
        //5、根据成员变量名称的key去字典中查找对应的value
        id value = dict[key];
        //↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑⬆︎⬆︎⬆︎
        //↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↑⬇︎⬇︎⬇︎
        //二级转换：如果字典中还有字典
        if ([value isKindOfClass:[NSDictionary class]]) {
            //获取成员变量的数据类型
            const char *ivarType = ivar_getTypeEncoding(ivar);
            NSString *type = [NSString stringWithUTF8String:ivarType];
            NSLog(@"dictType -- %@",type);//@\"NSDictionary\"
            
            //获取起始位置的转义符号和双引号\"
            NSRange range1 = [type rangeOfString:@"\""];
            NSLog(@"range -- %@",NSStringFromRange(range1));
            //从转义符之后开始截取子字符串
            NSString *subStr1 = [type substringFromIndex:range1.location + range1.length];
            //获取结束位置的转义符号和双引号\"
            NSRange range2 = [subStr1 rangeOfString:@"\""];
            //两个\"之间的内容就是该成员的类型名称
            NSString *classStr = [subStr1 substringToIndex:range2.location];
            
            //根据字符串名字生成类对象
            Class classModel = NSClassFromString(classStr);
            //进行二次转换
            if (classModel) {
                //字典转模型，并把模型赋值给value
                value = [classModel modelWithDict:value];
            }
        }
        //↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑⬆︎⬆︎⬆︎
        //↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↑⬇︎⬇︎⬇︎
        //三级转换：如果字典中还有数组（数组中包含字典或非字典）
        if ([value isKindOfClass:[NSArray class]]) {
//            if ([self instancesRespondToSelector:@selector(arrayContainObjects)]) {
            if ([self respondsToSelector:@selector(arrayContainObjects)]) {
                id idSelf = self;
                //根据字典中对应的key获取value
                NSString *arrValue = [idSelf arrayContainObjects][key];
                NSLog(@"arrValue -- %@",arrValue);
                //根据字符串名称生成类对象
                Class classModel = NSClassFromString(arrValue);
                //遍历字典数组，生成模型数组
                NSMutableArray *mArr = [NSMutableArray array];
                for (NSDictionary *dict in value) {
                    //字典模型
                    id model = [classModel modelWithDict:dict];
                    [mArr addObject:model];
                }
                //把模型数组赋值给value
                value = mArr;
            }
        }
        //↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑⬆︎⬆︎⬆︎
        //6、用kvc对模型赋值
        if (value) {
            [objc setValue:value forKey:key];
        }
    }
    
    return objc;
}

@end
