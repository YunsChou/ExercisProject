//
//  QuestUseController.h
//  runtimeSwizzleDemo
//
//  Created by weiying on 16/5/19.
//  Copyright © 2016年 Yuns. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QuestUseController : UIViewController

@end
