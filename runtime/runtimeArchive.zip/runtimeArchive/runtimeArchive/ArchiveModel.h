//
//  ArchiveModel.h
//  runtimeArchive
//
//  Created by weiying on 16/3/18.
//  Copyright © 2016年 Yuns. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ArchiveModel : NSObject<NSCoding>

@property (nonatomic, copy) NSString *abc;

@property (nonatomic, copy) NSString *def;

@property (nonatomic, copy) NSString *ghi;

@end
