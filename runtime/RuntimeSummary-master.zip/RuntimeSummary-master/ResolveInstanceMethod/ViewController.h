//
//  ViewController.h
//  ResolveInstanceMethod
//
//  Created by 朔 洪 on 16/4/21.
//  Copyright © 2016年 Tuccuay. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

