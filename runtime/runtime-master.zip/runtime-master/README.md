# runtime

####runtime 7种常用方法

![image](https://raw.githubusercontent.com/suifengqjn/demoimages/master/runtime/2.png)


详细讲解请看博客：[http://gcblog.github.io/2016/04/16/runtime%E8%AF%A6%E8%A7%A3/#more](http://gcblog.github.io/2016/04/16/runtime%E8%AF%A6%E8%A7%A3/#more)

或者[http://www.jianshu.com/p/46dd81402f63](http://www.jianshu.com/p/46dd81402f63)

