//
//  Person.m
//  runtime
//
//  Created by qianjianeng on 16/4/16.
//  Copyright © 2016年 SF. All rights reserved.
//

#import "Person.h"

@implementation Person

- (NSString *)saySex
{
    return @"i am a boy";
}
- (NSString *)sayName
{
    return @"my name is xiaoMing";
}
@end
