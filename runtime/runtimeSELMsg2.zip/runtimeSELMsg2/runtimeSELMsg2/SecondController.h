//
//  SecondController.h
//  runtimeSELMsg2
//
//  Created by weiying on 16/3/8.
//  Copyright © 2016年 Yuns. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondController : UIViewController

@end
