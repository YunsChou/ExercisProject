//
//  FoodData.h
//  YsLinkTableView
//
//  Created by weiying on 16/2/14.
//  Copyright © 2016年 Yuns. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FoodData : NSObject

+ (NSArray *)foodData;

@end
