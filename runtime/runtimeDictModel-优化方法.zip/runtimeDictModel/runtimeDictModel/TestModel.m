//
//  TestModel.m
//  runtimeDictModel
//
//  Created by weiying on 16/3/14.
//  Copyright © 2016年 Yuns. All rights reserved.
//

#import "TestModel.h"

@implementation TestModel

+ (NSDictionary *)arrayContainModelClass
{
    return @{@"subs" : @"TestSubModel"};
}

@end

@implementation TestSubModel


@end
