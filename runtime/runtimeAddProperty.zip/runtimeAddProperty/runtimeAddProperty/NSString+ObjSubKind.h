//
//  NSString+ObjSubKind.h
//  runtimeAddProperty
//
//  Created by weiying on 16/3/10.
//  Copyright © 2016年 Yuns. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (ObjSubKind)

+ (void)test;

@end
