//
//  NSString+ObjSubKind.m
//  runtimeAddProperty
//
//  Created by weiying on 16/3/10.
//  Copyright © 2016年 Yuns. All rights reserved.
//

#import "NSString+ObjSubKind.h"

@implementation NSString (ObjSubKind)

+ (void)test
{
    NSLog(@"%s", __func__);
}

@end
